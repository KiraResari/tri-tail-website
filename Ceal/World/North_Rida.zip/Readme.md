* Copy map file to `[User Home]\Documents\My Games\OldWorld\Maps` 
* After that, start a new game, set the map type to "Custom" and select the map from the dropdown